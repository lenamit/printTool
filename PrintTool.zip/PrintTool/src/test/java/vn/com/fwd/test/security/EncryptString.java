package vn.com.fwd.test.security;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class EncryptString {

	public static void main(String[] args) {
		try {
			String value = "svc_misods";
			
            IvParameterSpec iv = new IvParameterSpec("randomheyvectork".getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec("fwdrandomvalueky".getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

            byte[] encrypted = cipher.doFinal(value.getBytes());
            System.out.println("encrypted string: " + Base64.encodeBase64String(encrypted));
        } catch (Exception ex) {
            ex.printStackTrace();
        }

	}

}
