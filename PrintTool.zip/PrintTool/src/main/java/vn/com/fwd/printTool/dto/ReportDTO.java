package vn.com.fwd.printTool.dto;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class ReportDTO {
	private String policyNumber;
	private String planCode;
	private String statusCode;
	private String chanelCD;
	private String register;
	private String issueDate;
	private String afiDate;
	private String fullName;
	private String brachID;
	private String producingAgentCode;
	private String agentName;
	private String planType;
}
