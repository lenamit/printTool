package vn.com.fwd.printTool.dao;

import java.util.List;

import vn.com.fwd.printTool.entity.PrintToolConfiguration;
import vn.com.fwd.printTool.entity.User;

public class PrintToolConfigurationDao extends AbstractDao {
	public void create(PrintToolConfiguration config) throws Exception {
		super.saveOrUpdate(config);
	}
	public void delete(PrintToolConfiguration config) throws Exception {
		super.delete(config);
	}
	public void update(PrintToolConfiguration config) throws Exception {
		super.saveOrUpdate(config);
	}
	public PrintToolConfiguration findByName(String name) throws Exception {
		return (PrintToolConfiguration) super.find(PrintToolConfiguration.class, name);
	}
	@SuppressWarnings("unchecked")
	public List<PrintToolConfiguration> findAll() throws Exception {
		return super.findAll(PrintToolConfiguration.class);
	}
}
