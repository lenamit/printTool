package vn.com.fwd.printTool.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import vn.com.fwd.printTool.util.HibernateUtil;

import org.hibernate.Query;

import java.util.List;

public abstract class AbstractDao {
    private Session session;
    private Transaction tx;

    public AbstractDao() {
        HibernateUtil.getSQLSessionFactory();
    }

    protected void saveOrUpdate(Object obj) {
        try {
            startOperation();
            session.saveOrUpdate(obj);
            tx.commit();
        } catch (HibernateException e) {
            handleException(e);
        } finally {
        	HibernateUtil.close(session);
        }
    }

    protected void delete(Object obj) {
        try {
            startOperation();
            session.delete(obj);
            tx.commit();
        } catch (HibernateException e) {
            handleException(e);
        } finally {
        	HibernateUtil.close(session);
        }
    }

    @SuppressWarnings("rawtypes")
	protected Object find(Class clazz, String id) {
        Object obj = null;
        try {
            startOperation();
//            obj = session.load(clazz, id);
            obj = session.get(clazz, id);
            tx.commit();
        } catch (HibernateException e) {
            handleException(e);
        } finally {
        	HibernateUtil.close(session);
        }
        return obj;
    }

    @SuppressWarnings("rawtypes")
	protected List findAll(Class clazz) {
        List objects = null;
        try {
            startOperation();
            Query query = session.createQuery("from " + clazz.getName());
            objects = query.list();
            tx.commit();
        } catch (HibernateException e) {
            handleException(e);
        } finally {
        	HibernateUtil.close(session);
        }
        return objects;
    }

    protected void handleException(HibernateException e) throws HibernateException {
    	HibernateUtil.rollback(tx);
        throw e;
    }

    protected void startOperation() throws HibernateException {
        session = HibernateUtil.getSQLSessionFactory().getCurrentSession();
        tx = session.beginTransaction();
    }
}