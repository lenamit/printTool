package vn.com.fwd.printTool.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Utils {
	public static String getFile(String fileName) {
		Utils utils = new Utils();
		ClassLoader classLoader = utils.getClass().getClassLoader();
		return classLoader.getResource(fileName).getPath();
	}
	
	public static Properties getInputStreamResource(String fileName) {
		Utils utils = new Utils();
		ClassLoader classLoader = utils.getClass().getClassLoader();
		Properties props = new Properties();
		InputStream resourceStream = classLoader.getResourceAsStream(fileName);
	    try {
			props.load(resourceStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (resourceStream != null) {
				try {
					resourceStream.close();
					resourceStream = null;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return props;
	}
}
