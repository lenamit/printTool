package vn.com.fwd.printTool.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import vn.com.fwd.printTool.dao.PolicyTypeDao;
import vn.com.fwd.printTool.entity.PolicyType;
import vn.com.fwdprintTool.services.PrintToolServices;


public class PolicyTypeDialog extends JDialog {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Logger log = Logger.getLogger(PolicyTypeDialog.class);
	
	private PrintToolServices printToolServices;

	public PolicyTypeDialog(final PolicyType policyType, final PrintUI printUI) {
		try {
			if (printToolServices == null) {
				printToolServices = PrintToolServices.getInstant();
			}
			JPanel panel = new JPanel(false);
			panel.setLayout(null);
			// policy type
			JLabel lpolicyType = new JLabel("Policy Type Name:");
			lpolicyType.setBounds(20, 10, 200, 14);
			panel.add(lpolicyType);
			final JTextField fPolicyType = new JTextField();
			fPolicyType.setBounds(20, 34, 400, 20);
			if (policyType != null) {
				fPolicyType.setText(policyType.getPolicyType());
			}
			panel.add(fPolicyType);
			
			// sql
			JLabel lsql = new JLabel("SQL Configuration:");
			lsql.setBounds(20, 64, 200, 14);
			panel.add(lsql);
			final JTextArea sql = new JTextArea();
			sql.setBounds(20, 88, 400, 300);
			if (policyType != null) {
				sql.setText(policyType.getSql());
			}
			panel.add(sql);
			
			// button save
			JButton bSave = new JButton("Save");
			bSave.setBounds(45, 398, 100, 30);
			panel.add(bSave);
			bSave.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// check empty field
					String policyTypeName = fPolicyType.getText();
					String strSQL = sql.getText();
					if (!policyTypeName.isEmpty() && !strSQL.isEmpty()) {
						PolicyTypeDao typeDao = new PolicyTypeDao();
						try {
							// delete
							if (policyType != null) {
								typeDao.delete(policyType);
							}
							// save
							PolicyType policyTypeNew = new PolicyType();
							policyTypeNew.setPolicyType(policyTypeName);
							policyTypeNew.setSql(strSQL);
							typeDao.create(policyTypeNew);
						} catch (Exception e1) {
							log.error(e);
							e1.printStackTrace();
						}
						// close dialog
						dispose();
						printUI.setEnabled(true);
						loadDataForPrintUI(printUI);
					} else {
						JOptionPane.showMessageDialog(null, "please, enter policy type name and sql configuration !");
					}
				}
			});
			
			// button delete
			JButton bDelete = new JButton("Delete");
			bDelete.setBounds(155, 398, 100, 30);
			if (policyType == null) {
				bDelete.setEnabled(false);
			} else {
				bDelete.setEnabled(true);
			}
			panel.add(bDelete);
			bDelete.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// delete
					PolicyTypeDao typeDao = new PolicyTypeDao();
					try {
						// delete
						if (policyType != null) {
							typeDao.delete(policyType);
						}
					} catch (Exception e1) {
						log.error(e);
					}
					// close dialog
					dispose();
					printUI.setEnabled(true);
					loadDataForPrintUI(printUI);
				}
			});
			
			// button cancel
			JButton bCancel = new JButton("Cancel");
			bCancel.setBounds(265, 398, 100, 30);
			panel.add(bCancel);
			bCancel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// close dialog
					dispose();
					printUI.setEnabled(true);
				}
			});
			
			add(panel);
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	private void loadDataForPrintUI(PrintUI printUI) {
		try {
			// load data for table policy type in tab 2
			printUI.getTable().setModel(printToolServices.getModelforTable());
			// load data for  policy type in tab 1
			printToolServices.loadDataForPolicyType(printUI.getComTypePolicys());
		} catch (Exception e) {
			log.error(e);
		}
	}
}
