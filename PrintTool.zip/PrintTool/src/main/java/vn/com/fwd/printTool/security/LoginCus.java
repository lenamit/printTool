package vn.com.fwd.printTool.security;

import java.util.List;

import javax.security.auth.login.FailedLoginException;

import org.apache.log4j.Logger;

import vn.com.fwd.printTool.dao.UserDao;
import vn.com.fwd.printTool.entity.User;

public class LoginCus extends UserDao {
	private Logger log = Logger.getLogger(LoginCus.class);
	private String userName;
	private String password;
	private List<User> lstUser;
	public LoginCus(String userName, String password) {
		try {
			this.userName = userName;
			this.password = password;
			UserDao dao = new UserDao();
			lstUser = dao.findAll();
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	public boolean login() throws Exception {
		boolean authenticationSucessFlag = false;
		try {
			if (lstUser != null) {
				for (User user : lstUser) {
					if (user.getUserName().equals(userName) && user.getPassWord().equals(password)) {
						authenticationSucessFlag = true;
						log.info("authentication success ...");
						break;
					} else {
						authenticationSucessFlag = false;
					}
				}
			}
			if (!authenticationSucessFlag) {
				log.info("authentication failure ...");
				throw new FailedLoginException("authentication failure ...");
			}
		} catch (Exception e) {
			log.error(e);
			throw e;
		}
		return authenticationSucessFlag;
	}
}
