package vn.com.fwd.printTool.dao;

import java.util.List;

import vn.com.fwd.printTool.entity.PolicyType;

public class PolicyTypeDao extends AbstractDao {
	public void create(PolicyType policyType) throws Exception {
		super.saveOrUpdate(policyType);
	}
	public void delete(PolicyType policyType) throws Exception {
		super.delete(policyType);
	}
	public void update(PolicyType policyType) throws Exception {
		super.saveOrUpdate(policyType);
	}
	public PolicyType findByPolicyType(String policyType) throws Exception {
		return (PolicyType) super.find(PolicyType.class, policyType);
	}
	@SuppressWarnings("unchecked")
	public List<PolicyType> findAll() throws Exception {
		return super.findAll(PolicyType.class);
	}
}
