package vn.com.fwd.printTool.security;

import java.io.IOException;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

public class PrintCallbackHandler implements CallbackHandler {
	private String userName;
	private String passWord;
	public PrintCallbackHandler(String userName, String passWord) {
		this.userName = userName;
		this.passWord = passWord;
	}
	
	public void handle(Callback[] callbacks) throws IOException, UnsupportedCallbackException {
		NameCallback nameCallback = null;
		PasswordCallback passwordCallback = null;
		int counter = 0;
		while (counter < callbacks.length) {
			if (callbacks[counter] instanceof NameCallback) {
				nameCallback = (NameCallback) callbacks[counter++];
//				System.out.println(nameCallback.getPrompt());
//				nameCallback.setName(new BufferedReader(new InputStreamReader(System.in)).readLine());
				nameCallback.setName(userName);
			} else if (callbacks[counter] instanceof PasswordCallback) {
				passwordCallback = (PasswordCallback) callbacks[counter++];
//				System.out.println(passwordCallback.getPrompt());
//				passwordCallback.setPassword(new BufferedReader(new InputStreamReader(System.in)).readLine().toCharArray());
				passwordCallback.setPassword(passWord.toCharArray());
			}
		}
	}

}
