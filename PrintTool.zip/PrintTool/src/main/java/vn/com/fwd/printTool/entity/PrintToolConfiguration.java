package vn.com.fwd.printTool.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)

@Entity
@Table(name="print_tool_configuration")
public class PrintToolConfiguration {
	@Id
	@Column(name="name")
	private String name;
	@Column(name="value")
	private String value;
}
