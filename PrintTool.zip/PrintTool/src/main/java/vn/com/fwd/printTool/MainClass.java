package vn.com.fwd.printTool;

import java.awt.event.WindowAdapter;

import org.apache.log4j.Logger;
import org.hibernate.SessionFactory;

import vn.com.fwd.printTool.ui.LoginUI;
import vn.com.fwd.printTool.util.HibernateUtil;

public class MainClass {
	private static Logger log = Logger.getLogger(MainClass.class);

	public static void main(String[] args) {
		try {
//			String pathFileResource = Utils.getFile("printToolSecurity.properties");
//			System.out.println("pathFileResource : " + pathFileResource);
//			System.setProperty("java.security.auth.login.config", pathFileResource);
			LoginUI login = new LoginUI();
			login.setBounds(100, 100, 450, 200);
			login.setVisible(true);
			login.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(java.awt.event.WindowEvent windowEvent) {
					SessionFactory sessionFactory = HibernateUtil.getSQLSessionFactory();
			        if (sessionFactory != null && !sessionFactory.isClosed()) {
						sessionFactory.close();
					}
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
		}
	}
	

}
