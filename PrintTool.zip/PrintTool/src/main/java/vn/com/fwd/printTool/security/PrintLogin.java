package vn.com.fwd.printTool.security;

import java.util.List;
import java.util.Map;

import javax.security.auth.Subject;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.login.FailedLoginException;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import vn.com.fwd.printTool.entity.User;
import vn.com.fwdprintTool.services.PrintToolServices;

public class PrintLogin implements LoginModule {
	private CallbackHandler callbackHandler = null;
	private List<User> lstUsers;
	private boolean authenticationSucessFlag = false;

	public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> sharedState,
			Map<String, ?> options) {
		this.callbackHandler = callbackHandler;
//		SessionFactory sessionFactory = null;
		try {
			PrintToolServices service = PrintToolServices.getInstant();
			lstUsers = service.getAllUser();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
//			if (sessionFactory != null && !sessionFactory.isClosed()) {
//				sessionFactory.close();
//			}
		}
	}

	public boolean login() throws LoginException {
		Callback[] callbackArray = new Callback[2];
		callbackArray[0] = new NameCallback("User Name:");
		callbackArray[1] = new PasswordCallback("Password:", false);
		try {
			callbackHandler.handle(callbackArray);
		} catch (Exception e) {
			e.printStackTrace();
		}
		String userName = ((NameCallback) callbackArray[0]).getName();
		String pass = new String(((PasswordCallback) callbackArray[1]).getPassword());
		for (User user : lstUsers) {
			if (user.getUserName().equals(userName) && user.getPassWord().equals(pass)) {
				authenticationSucessFlag = true;
				System.out.println("authentication success ...");
				break;
			} else {
				authenticationSucessFlag = false;
			}
		}
		if (!authenticationSucessFlag) {
			System.out.println("authentication failure ...");
			throw new FailedLoginException("authentication failure ...");
		}
		return authenticationSucessFlag;
	}

	public boolean commit() throws LoginException {
		return authenticationSucessFlag;
	}

	public boolean abort() throws LoginException {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean logout() throws LoginException {
		// TODO Auto-generated method stub
		return false;
	}

}
