package vn.com.fwd.printTool.ui;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.io.File;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.apache.log4j.Logger;
import org.jdesktop.swingx.JXDatePicker;

import vn.com.fwd.printTool.dao.PolicyTypeDao;
import vn.com.fwd.printTool.dto.ReportDTO;
import vn.com.fwd.printTool.entity.PolicyType;
import vn.com.fwd.printTool.security.LoginCus;
import vn.com.fwdprintTool.services.PrintToolServices;

public class PrintUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Logger log = Logger.getLogger(PrintUI.class);
	
	private PrintToolServices printToolServices;
	
	// jcombobox policy type
	private JComboBox<String> comTypePolicys;
	// table policy type
	private JTable table;
	
	public PrintUI(String userName, String password) {
		// authentication
		try {
//			LoginContext loginContext = null;
//			loginContext = new LoginContext("PrintTool", new PrintCallbackHandler(userName, password));
//			loginContext.login();
			LoginCus login = new LoginCus(userName, password);
			login.login();
			
			if (printToolServices == null) {
				printToolServices = PrintToolServices.getInstant();
			}
			if (userName.equalsIgnoreCase("admin")) {
				initComponents(true);
			} else {
				initComponents(false);
			}
		} catch (Exception e){
			JOptionPane.showMessageDialog(null, "user name, password is incorrect !");
			System.out.println(e.getMessage());
		}
	}
	
	private void initComponents(boolean blnAdmin) {
		try {
			setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			JTabbedPane tabbedPane = new JTabbedPane();
			tabbedPane.addTab("Print", makePanelPrint());
			
			if (blnAdmin) {
				tabbedPane.addTab("Configuration Policy Type", makePanelSetting());
			}
			
			getContentPane().add(tabbedPane);
			
			pack();
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	private JComponent makePanelPrint() {
		try {
			final DateFormat df = new SimpleDateFormat("ddMMyyyy");
			
	        JPanel panel = new JPanel(false);
	        panel.setLayout(null);
	        // policy type
	        JLabel lTypePolicy = new JLabel("Type Policy:");
	        lTypePolicy.setBounds(35, 23, 80, 14);
	        panel.add(lTypePolicy);
	        comTypePolicys = new JComboBox<String>();
	        comTypePolicys.setBounds(125, 20, 200, 20);
	        // get from config
	        printToolServices.loadDataForPolicyType(comTypePolicys);
	        panel.add(comTypePolicys);
	        
	        // report date
	        JLabel lDate = new JLabel("Report Date:");
	        lDate.setBounds(35, 50, 80, 14);
	        panel.add(lDate);
	        final JXDatePicker jDateReport = new JXDatePicker();
	        jDateReport.setBounds(125, 47, 200, 20);
	        jDateReport.setDate(new Date());
	        jDateReport.setFormats(new SimpleDateFormat("dd-MM-yyyy"));
	        panel.add(jDateReport);
	        
	        // path save Excel file
	        JLabel lFileExcel = new JLabel("Excel Report:");
	        lFileExcel.setBounds(35, 73, 80, 14);
	        panel.add(lFileExcel);
	        final JTextField fFolderExcel = new JTextField();
	        fFolderExcel.setBounds(125, 70, 200, 20);
	        panel.add(fFolderExcel);
	        JButton bBrower = new JButton("Brower");
	        bBrower.setBounds(330, 70, 80, 20);
	        panel.add(bBrower);
	        
	        final JFileChooser fileExcel = new JFileChooser();
	        //set a default filename (this is where you default extension first comes in)
	        String fileName = "DS HD PHAT HANH " + df.format(jDateReport.getDate() == null ? new Date() : jDateReport.getDate()) + ".xlsx";
	        fileExcel.setSelectedFile(new File(fileName));
	        //Set an extension filter, so the user sees other XML files
	        fileExcel.setFileFilter(new FileNameExtensionFilter("*.xlsx","xlsx"));
	        
	        bBrower.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// set name 
					String fileNameNew = "DS HD PHAT HANH " + (String)comTypePolicys.getSelectedItem() + " " + df.format(jDateReport.getDate() == null ? new Date() : jDateReport.getDate()) + ".xlsx";
					fileExcel.setSelectedFile(new File(fileNameNew));
					int returnVal = fileExcel.showSaveDialog(PrintUI.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File file = fileExcel.getSelectedFile();
						String filePath = file.getPath();
						if (!filePath.endsWith(".xlsx")) {
							filePath += ".xlsx";
						}
						fFolderExcel.setText(filePath);
					}
				}
			});
	        
	        // chooser printer
	        JLabel lPrinter = new JLabel("Printer:");
	        lPrinter.setBounds(35, 96, 80, 14);
	        panel.add(lPrinter);
	        final JComboBox<String> comPrinter = new JComboBox<String>();
	        comPrinter.setBounds(125, 96, 200, 20);
	        List<String> lstPrinter = printToolServices.getAllPrinter();
	        if (lstPrinter != null && lstPrinter.size() > 0) {
	        	for (String priterName : lstPrinter) {
	        		comPrinter.addItem(priterName);
	        	}
	        }
	        panel.add(comPrinter);
	        
	        // button report
	        JButton bReport = new JButton("Report");
	        bReport.setBounds(95, 127, 100, 30);
	        panel.add(bReport);
	        bReport.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// check empty value
					final String policyTypeNameTmp = (String) comTypePolicys.getSelectedItem();
					Date reportDateTmp = jDateReport.getDate();
					final String filePathExcelTmp = fFolderExcel.getText();
					String printerNameTmp = (String) comPrinter.getSelectedItem();
					if (!policyTypeNameTmp.isEmpty() && reportDateTmp != null 
							&& !filePathExcelTmp.isEmpty() && !printerNameTmp.isEmpty()) {
						// get data
						try {
							final List<ReportDTO> lstTmp = printToolServices.getDataToPrintAndReport(policyTypeNameTmp, reportDateTmp);
							if (lstTmp != null) {
								log.info("lstTmp.size(): " + lstTmp.size());
								// export excel
								Thread tExportExcel = new Thread() {
									public void run() {
										// export excel
										try {
											printToolServices.toExcel(lstTmp, filePathExcelTmp, policyTypeNameTmp);
										} catch (SQLException e) {
											log.error(e);
										}
									};
								};
								tExportExcel.start();
								// wait thread end
								tExportExcel.join();
							} else {
								log.info("no data !!!!!!!!!");
							}
						} catch (Exception e1) {
							log.error(e);
						}
					} else {
						JOptionPane.showMessageDialog(null, "please, choose Policy Type, Report Date, and Excel Report !");
					}
				}
			});
	        
	        // button Report and print
	        JButton bReportPrint = new JButton("Print and Report");
	        bReportPrint.setBounds(205, 127, 150, 30);
	        panel.add(bReportPrint);
	        bReportPrint.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// check empty value
					final String policyTypeNameTmp = (String) comTypePolicys.getSelectedItem();
					Date reportDateTmp = jDateReport.getDate();
					final String filePathExcelTmp = fFolderExcel.getText();
					final String printerNameTmp = (String) comPrinter.getSelectedItem();
					if (!policyTypeNameTmp.isEmpty() && reportDateTmp != null 
							&& !filePathExcelTmp.isEmpty() && !printerNameTmp.isEmpty()) {
						// get data
						try {
							final List<ReportDTO> lstTmp = printToolServices.getDataToPrintAndReport(policyTypeNameTmp, reportDateTmp);
							if (lstTmp != null) {
								System.out.println("lstTmp.size(): " + lstTmp.size());
								// export excel
								Thread tExportExcel = new Thread() {
									public void run() {
										// export excel
										try {
											printToolServices.toExcel(lstTmp, filePathExcelTmp, policyTypeNameTmp);
										} catch (SQLException e) {
											log.error(e);
										}
									};
								};
								tExportExcel.start();
								// print document
								Thread tPrint = new Thread() {
									public void run() {
										try {
											printToolServices.printPDF(lstTmp, printerNameTmp);
										} catch (Exception e) {
											log.error(e);
										}
									};
								};
								tPrint.start();
								// wait thread end
								tExportExcel.join();
								tPrint.join();
							} else {
								System.out.println("no data !!!!!!!!!");
							}
						} catch (Exception e1) {
							log.error(e);
						}
					} else {
						JOptionPane.showMessageDialog(null, "please, choose Policy Type, Report Date, and Excel Report !");
					}
				}
			});
	        
	        return panel;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
    }
	
	private JComponent makePanelSetting() throws Exception {
		try {
	        JPanel panel = new JPanel(false);
	        panel.setLayout(null);
	        
	        // button new
	        JButton bNew = new JButton("New");
	        bNew.setBounds(285, 20, 120, 25);
	        panel.add(bNew);
	        bNew.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// show dialog new policy type
					showPolicyTypeDialog(null);
					// disable print UI
					setEnabled(false);
				}
			});
	        
	        // policy type
	        JLabel lTypePolicy = new JLabel("List Type of Policy:");
	        lTypePolicy.setBounds(35, 45, 200, 14);
	        panel.add(lTypePolicy);
	        
	        // data table
	        table = new JTable();
	        table.setPreferredScrollableViewportSize(new Dimension(370, 200));
	        table.setFillsViewportHeight(true);
	        table.setModel(printToolServices.getModelforTable());
	        table.addMouseListener(new java.awt.event.MouseAdapter() {
	            @Override
	            public void mousePressed(MouseEvent mouseEvent) {
	                JTable table =(JTable) mouseEvent.getSource();
	                Point point = mouseEvent.getPoint();
	                int row = table.rowAtPoint(point);
	                if (row > -1) {
		                if (mouseEvent.getClickCount() == 2 && table.getSelectedRow() != -1) {
		                    // edit row
		                	String sqlPolicyTypeName = (String)table.getModel().getValueAt(row, 0);
		                	PolicyTypeDao policyTypeDao = new PolicyTypeDao();
		                	try {
								PolicyType policyType = policyTypeDao.findByPolicyType(sqlPolicyTypeName);
								// show dialog new policy type
								showPolicyTypeDialog(policyType);
								setEnabled(false);
								// disable print UI
							} catch (Exception e) {
								log.error(e);
							}
		                }
	                }
	            }
	        });
	      //Create the scroll pane and add the table to it.
	        JScrollPane scrollPane = new JScrollPane(table);
	        scrollPane.setBounds(35, 70, 370, 200);
	        panel.add(scrollPane);
	        return panel;
		} catch (Exception e) {
			log.error(e);
			throw e;
		}
    }
	
	private void showPolicyTypeDialog(PolicyType policyType) {
		// show dialog new policy type
		JDialog policyTypeDialog = new PolicyTypeDialog(policyType, this);
		policyTypeDialog.setBounds(100, 100, 450, 480);
//		policyTypeDialog.show();
		policyTypeDialog.setVisible(true);
	}

	public JComboBox<String> getComTypePolicys() {
		return comTypePolicys;
	}

	public void setComTypePolicys(JComboBox<String> comTypePolicys) {
		this.comTypePolicys = comTypePolicys;
	}

	public JTable getTable() {
		return table;
	}

	public void setTable(JTable table) {
		this.table = table;
	}
	
}
