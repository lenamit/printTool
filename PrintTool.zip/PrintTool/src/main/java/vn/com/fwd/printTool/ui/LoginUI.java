package vn.com.fwd.printTool.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;

import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import org.hibernate.SessionFactory;

import vn.com.fwd.printTool.security.LoginCus;
import vn.com.fwd.printTool.security.PrintCallbackHandler;
import vn.com.fwd.printTool.util.HibernateUtil;

public class LoginUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private JLabel jLabelUserName;
	private JTextField fUserName;
	// password
	private JLabel jLabelPassword;
	private JPasswordField fPassword;
	private JButton bLogin;
	
	private boolean blLogin = false;
	
	public LoginUI() {
		initComponents();
	}
	
	private void initComponents() {
        fUserName = new JTextField();
        jLabelUserName = new JLabel("User Name:");
        jLabelPassword = new JLabel("Password:");
        fPassword = new JPasswordField();
        bLogin = new JButton("Login");
        
        setTitle("LOGIN");
        getContentPane().setLayout(null);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        jLabelUserName.setBounds(35, 31, 100, 14);
        getContentPane().add(jLabelUserName);
        fUserName.setBounds(150, 28, 200, 20);
        getContentPane().add(fUserName);
        jLabelPassword.setBounds(35, 55, 100, 14);
        getContentPane().add(jLabelPassword);
        fPassword.setBounds(150, 55, 200, 20);
        getContentPane().add(fPassword);
        bLogin.setBounds(125, 95, 150, 30);
        getContentPane().add(bLogin);
        
        bLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String userName = fUserName.getText();
				String password = fPassword.getText();
				if(userName.isEmpty() || password.isEmpty()) {
					JOptionPane.showMessageDialog(null, "please, enter user name and password");
				} else {
//					LoginContext loginContext = null;
					try {
						LoginCus login = new LoginCus(userName, password);
						login.login();
//						loginContext = new LoginContext("PrintTool", new PrintCallbackHandler(userName, password));
//						loginContext.login();
						blLogin = true;
						// dispose;
						dispose();
						// create ui print
						PrintUI print = new PrintUI(userName, password);
						print.setBounds(100, 100, 450, 400);
						print.setVisible(true);
						print.addWindowListener(new WindowAdapter() {
							 @Override
							    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
							        System.out.println("aaaaaaaaaaaaaaaaaa");
							        SessionFactory sessionFactory = HibernateUtil.getSQLSessionFactory();
							        if (sessionFactory != null && !sessionFactory.isClosed()) {
										sessionFactory.close();
									}
							    }
						});
						
					} catch (Exception e) {
						blLogin = false;
						JOptionPane.showMessageDialog(null, "user name, password is incorrect !");
						System.out.println(e.getMessage());
					}
				}
			}
		});
        
		pack();
    }
	
	public boolean isBlLogin() {
		return blLogin;
	}
	
}
