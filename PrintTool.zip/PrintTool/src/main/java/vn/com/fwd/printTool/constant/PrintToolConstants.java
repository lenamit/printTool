package vn.com.fwd.printTool.constant;

public class PrintToolConstants {
	public static String BASEFOLDER="BASEFOLDER";
	public static String KEY_ENCRYPT = "fwdrandomvalueky";
	public static String INITVECTOR = "randomheyvectork";
}
