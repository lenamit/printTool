package vn.com.fwd.printTool.dao;

import java.util.List;

import vn.com.fwd.printTool.entity.User;

public class UserDao extends AbstractDao {
	public void create(User user) throws Exception {
		super.saveOrUpdate(user);
	}
	public void delete(User user) throws Exception {
		super.delete(user);
	}
	public void update(User user) throws Exception {
		super.saveOrUpdate(user);
	}
	public User findByUserName(String userNam) throws Exception {
		return (User) super.find(User.class, userNam);
	}
	@SuppressWarnings("unchecked")
	public List<User> findAll() throws Exception {
		return super.findAll(User.class);
	}
}
