package vn.com.fwd.printTool.util;

import java.util.Properties;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.boot.registry.internal.StandardServiceRegistryImpl;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import vn.com.fwd.printTool.security.Encryptor;

public class HibernateUtil {

	private static SessionFactory sessionFactorySQL = buildSQLSessionFactory();
	
//	private static SessionFactory sessionFactoryODS = buildODSSessionFactory();

	private static ServiceRegistry serviceRegistrySQL;
	
//	private static ServiceRegistry serviceRegistryODS;
	
	private static Logger logger = Logger.getLogger(HibernateUtil.class);

	private static SessionFactory buildSQLSessionFactory() {
		try {
			Encryptor encryptor = Encryptor.getInstant();
			
			Configuration configuration = new Configuration();
			configuration.configure("/hibernate.cfg.xml");
			Properties properties = configuration.getProperties();
			String diverClass = encryptor.decrypt(properties.getProperty("connection.driver_class"));
//			properties.setProperty("connection.driver_class", diverClass);
			properties.setProperty("hibernate.connection.driver_class", diverClass);
			String url = encryptor.decrypt(properties.getProperty("connection.url"));
//			properties.setProperty("connection.url", url);
			properties.setProperty("hibernate.connection.url", url);
			String userName = encryptor.decrypt(properties.getProperty("connection.username"));
//			properties.setProperty("connection.username", userName);
			properties.setProperty("hibernate.connection.username", userName);
			String pass = encryptor.decrypt(properties.getProperty("connection.password"));
//			properties.setProperty("connection.password", pass);
			properties.setProperty("hibernate.connection.password", pass);
			configuration.setProperties(properties);
			/*String encryptedPwd = configuration.getProperty("hibernate.connection.password");
			String plainPwd = DecodePassword.decodePassword(encryptedPwd);
			configuration.setProperty("hibernate.connection.password", plainPwd);*/
			serviceRegistrySQL = new StandardServiceRegistryBuilder().applySettings(properties).build();
			sessionFactorySQL = configuration.buildSessionFactory(serviceRegistrySQL);
			return sessionFactorySQL;
		} catch (Throwable ex) {
			ex.printStackTrace();
			logger.error("Initial SessionFactory creation failed.", ex);
			throw new ExceptionInInitializerError(ex);
		}
	}
	
//	private static SessionFactory buildODSSessionFactory() {
//		try {
//			Configuration configuration = new Configuration();
////			Utils.getInputStreamResource("configPrintTool/hibernate_standalone_ODS.cfg.xml");
//			configuration.configure("/hibernate_standalone_ODS.cfg.xml");
////			configuration.setProperties(Utils.getInputStreamResource("hibernate_standalone_ODS.cfg.xml"));
//			/*String encryptedPwd = configuration.getProperty("hibernate.connection.password");
//			String plainPwd = DecodePassword.decodePassword(encryptedPwd);
//			configuration.setProperty("hibernate.connection.password", plainPwd);*/
//			serviceRegistryODS = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
//			sessionFactoryODS = configuration.buildSessionFactory(serviceRegistryODS);
//			return sessionFactoryODS;
//		} catch (Throwable ex) {
//			ex.printStackTrace();
//			logger.error("Initial SessionFactory creation failed.", ex);
//			throw new ExceptionInInitializerError(ex);
//		}
//	}

	public static void closeSQLSessionFactory() {
		((StandardServiceRegistryImpl) serviceRegistrySQL).destroy();
	}
	
//	public static void closeODSSessionFactory() {
//		((StandardServiceRegistryImpl) serviceRegistryODS).destroy();
//	}

	public static SessionFactory getSQLSessionFactory() {
		return sessionFactorySQL;
	}
	
//	public static SessionFactory getODSSessionFactory() {
//		return sessionFactoryODS;
//	}
	
	public static void close(Session session) {
        if (session != null && session.isConnected()) {
            try {
                session.close();
            } catch (HibernateException ignored) {
            	ignored.printStackTrace();
            }
        }
    }
	
	public static void rollback(Transaction tx) {
        try {
            if (tx != null) {
                tx.rollback();
            }
        } catch (HibernateException ignored) {
        	ignored.printStackTrace();
        }
    }

}