package vn.com.fwdprintTool.services;

import java.awt.print.PrinterJob;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.PrintService;
import javax.print.SimpleDoc;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.swing.JComboBox;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import vn.com.fwd.printTool.constant.PrintToolConstants;
import vn.com.fwd.printTool.dao.PolicyTypeDao;
import vn.com.fwd.printTool.dao.PrintToolConfigurationDao;
import vn.com.fwd.printTool.dao.UserDao;
import vn.com.fwd.printTool.dto.ReportDTO;
import vn.com.fwd.printTool.entity.PolicyType;
import vn.com.fwd.printTool.entity.PrintToolConfiguration;
import vn.com.fwd.printTool.entity.User;
import vn.com.fwd.printTool.security.Encryptor;
import vn.com.fwd.printTool.util.Utils;

public class PrintToolServices {
	private static PrintToolServices instant;
	private Logger log = Logger.getLogger(PrintToolServices.class);
	
	private Encryptor encrypt;
	
	public static PrintToolServices getInstant() {
		if (instant == null) {
			instant = new PrintToolServices();
		}
		return instant;
	}
	public List<User> getAllUser() throws Exception {
		List<User> lstResult = new ArrayList<User>();
		try {
			UserDao userDao = new UserDao();
			lstResult = userDao.findAll();
			return lstResult;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public List<ReportDTO> getDataToPrintAndReport(String typePolicy, Date reportDate) throws Exception {
		List<ReportDTO> lstResult = new ArrayList<ReportDTO>();
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			if (encrypt == null) {
				encrypt = Encryptor.getInstant();
			}
			
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
			
			Properties properties = Utils.getInputStreamResource("database_ods.properties");
			Class.forName(encrypt.decrypt(properties.getProperty("database.driver_class")));
			conn = DriverManager.getConnection(encrypt.decrypt(properties.getProperty("database.url")), 
					encrypt.decrypt(properties.getProperty("database.username")), 
					encrypt.decrypt(properties.getProperty("database.pass")));
			
			// get config sql by type policy
			PolicyTypeDao policyTypeDao = new PolicyTypeDao();
			PolicyType policyType = policyTypeDao.findByPolicyType(typePolicy);
			String sql = policyType.getSql();
			
			pst = conn.prepareStatement(sql);
			pst.setString(1, df.format(reportDate));
			rs= pst.executeQuery();
			while (rs.next()) {
				ReportDTO report = new ReportDTO();
				report.setPolicyNumber(rs.getString("POLICYNUMBER"));
				report.setPlanCode(rs.getString("PLANCODE"));
				report.setStatusCode(rs.getString("STATUSCODE"));
				report.setChanelCD(rs.getString("CHANNELCD"));
				report.setRegister(rs.getString("REGISTER"));
				report.setIssueDate(rs.getString("ISSUEDATE"));
				report.setAfiDate(rs.getString("AFIDATE"));
				report.setFullName(rs.getString("FULLNAME"));
				report.setBrachID(rs.getString("BRANCHID"));
				report.setProducingAgentCode(rs.getString("PRODUCINGAGENTCODE"));
				report.setAgentName(rs.getString("AGENTNAME"));
				report.setPlanType(rs.getString("PLANTYPE"));
				lstResult.add(report);
			}
			
			// get data
//			sqlQuery.setDate(0, reportDate);
			return lstResult;
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			throw e;
		} finally {
			if (rs != null) {rs.close(); rs = null;}
			if (pst != null) {pst.close(); pst = null;}
			if (conn != null) {conn.close(); conn = null;}
		}
	}
	
	public void toExcel(List<ReportDTO> lstReport, String filePathExcel, String sheetName) throws SQLException {
		try {
			// excel
			XSSFWorkbook workbook = new XSSFWorkbook();
			// sheet 05.04.2018
	        XSSFSheet sheet = workbook.createSheet(sheetName);
			
			int rowNum = 0;
			// header
			String[] headers = {"C_policynumber", "C_PLANCODE", "C_STATUSCODE", "C_CHANNELCD", "C_Register", "C_IssueDate", "C_AFIDate", 
					"C_FULLNAME", "C_BRANCHID", "C_PRODUCINGAGENTCODE", "C_AGENTNAME", "C_PLANTYPE"};
			Row rowHeader = sheet.createRow(rowNum++);
			for (int i = 0; i < headers.length; i++) {
				Cell cellHeader = rowHeader.createCell(i);
				cellHeader.setCellValue(headers[i]);
			}

			for (ReportDTO report : lstReport) {
	        	Row row = sheet.createRow(rowNum++);
            	Cell cellpolicynumber = row.createCell(0);
            	cellpolicynumber.setCellValue(report.getPolicyNumber());
            	
            	Cell cellPLANCODE = row.createCell(1);
            	cellPLANCODE.setCellValue(report.getPlanCode());
            	
            	Cell cellSTATUSCODE = row.createCell(2);
            	cellSTATUSCODE.setCellValue(report.getStatusCode());
            	
            	Cell cellCHANNELCD = row.createCell(3);
            	cellCHANNELCD.setCellValue(report.getChanelCD());
            	
            	Cell cellRegister = row.createCell(4);
            	cellRegister.setCellValue(report.getRegister());
            	
            	Cell cellIssueDate = row.createCell(5);
            	cellIssueDate.setCellValue(report.getIssueDate());
            	
            	Cell cellAFIDate = row.createCell(6);
            	cellAFIDate.setCellValue(report.getAfiDate());
            	
            	Cell cellFULLNAME = row.createCell(7);
            	cellFULLNAME.setCellValue(report.getFullName());
            	
            	Cell cellBRANCHID = row.createCell(8);
            	cellBRANCHID.setCellValue(report.getBrachID());
            	
            	Cell cellPRODUCINGAGENTCODE = row.createCell(9);
            	cellPRODUCINGAGENTCODE.setCellValue(report.getProducingAgentCode());
            	
            	Cell cellAGENTNAME = row.createCell(10);
            	cellAGENTNAME.setCellValue(report.getAgentName());
            	
            	Cell cellPLANTYPE = row.createCell(11);
            	cellPLANTYPE.setCellValue(report.getPlanType());
	        }
			
			FileOutputStream outputStream = new FileOutputStream(filePathExcel);
            workbook.write(outputStream);
            workbook.close();
            log.info("Done Excel");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
		}
	}
	
	public void printPDF(List<ReportDTO> lstReport, String printerName) throws Exception {
		try {
			PrintToolConfigurationDao configurationDao = new PrintToolConfigurationDao();
			PrintToolConfiguration configuration = configurationDao.findByName(PrintToolConstants.BASEFOLDER);
			String baseFolder = "";
			if (configuration != null) {
				baseFolder = configuration.getValue();
			}
			if (!baseFolder.isEmpty()) {
				File pdffolder = new File(baseFolder);
				if (pdffolder.exists() && pdffolder.isDirectory()) {
					for (ReportDTO report : lstReport) {
						final String policyNumber = report.getPolicyNumber();
						// find file Name by policy number
						File[] lstofpdf = pdffolder.listFiles(new FilenameFilter() {
							public boolean accept(File dir, String name) {									
								return name.toUpperCase().endsWith(".PDF") && name.contains("_" + policyNumber + "_");
							}
						});
						if (lstofpdf != null && lstofpdf.length > 0) {
							// get only file correct
							String filePath = "";
							for (File filePDF : lstofpdf) {
								String[] nameParts = filePDF.getName().split("_");
								if (nameParts.length > 6 && nameParts[5].equalsIgnoreCase(policyNumber)) {
									filePath = filePDF.getPath();
									break;
								}
							}
							if (!filePath.isEmpty()) {
								FileInputStream in = new FileInputStream(filePath);
								Doc doc = new SimpleDoc(in, DocFlavor.INPUT_STREAM.AUTOSENSE, null);
								PrintService service = findPrintService(printerName);
								service.createPrintJob().print(doc, new HashPrintRequestAttributeSet());
								in.close();
							} else {
								log.warn("File of policy number " + policyNumber + " is not exist in " + baseFolder);
								System.out.println("File of policy number " + policyNumber + " is not exist in " + baseFolder);
							}
						} else {
							log.warn("File of policy number " + policyNumber + " is not exist in " + baseFolder);
							System.out.println("File of policy number " + policyNumber + " is not exist in " + baseFolder);
						}
					}
				}
			}
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			throw e;
		}
	}
	
	private PrintService findPrintService(String printerName) throws Exception {
		try {
	        printerName = printerName.toLowerCase();
	        PrintService service = null;
	        // Get array of all print services
	        PrintService[] services = PrinterJob.lookupPrintServices();
	        // Retrieve a print service from the array
	        for (int index = 0; service == null && index < services.length; index++) {
	            if (services[index].getName().toLowerCase().indexOf(printerName) >= 0) {
	                service = services[index];
	            }
	        }
	        // Return the print service
	        return service;
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			throw e;
		}
    }
	
	public List<String> getAllPrinter() throws Exception{
		try {
			List<String> lstResult = new ArrayList<String>();
			PrintService[] services = PrinterJob.lookupPrintServices();
			for (PrintService printer : services) {
				lstResult.add(printer.getName());
			}
			return lstResult;
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			throw e;
		}
	}
	
	public TableModel getModelforTable() throws Exception {
		try {
			String[] strColumnName = {"Type of Policy", "Action"};
	        PolicyTypeDao policyTypeDao = new PolicyTypeDao();
	        String[][] dataPolicyTypes = {{"abc", "sql1"}, {"dasda", "sql2"}};
	        List<PolicyType> lstPolicyType = policyTypeDao.findAll();
			if (lstPolicyType != null && lstPolicyType.size() > 0) {
				dataPolicyTypes = new String[lstPolicyType.size()][2];
				int rowIndex = 0;
				for (PolicyType type : lstPolicyType) {
					String[] row = new String[2];
					row[0] = type.getPolicyType();
					row[1] = type.getSql();
					dataPolicyTypes[rowIndex] = row;
					rowIndex ++;
				}
			}
			TableModel model = new DefaultTableModel(dataPolicyTypes, strColumnName) {
				private static final long serialVersionUID = 1L;
	
				public boolean isCellEditable(int rowIndex, int mColIndex) {
	              return false;
	            }
	        };
	        return model;
		} catch (Exception e) {
			log.error(e);
			throw e;
		}
	} 
	
	public void loadDataForPolicyType(JComboBox<String> comTypePolicys) {
		PolicyTypeDao policyTypeDao = new PolicyTypeDao();
        try {
        	comTypePolicys.removeAllItems();
			List<PolicyType> lstPolicyType = policyTypeDao.findAll();
			if (lstPolicyType != null) {
				for (PolicyType policyType : lstPolicyType) {
					comTypePolicys.addItem(policyType.getPolicyType());
				}
			}
		} catch (Exception e1) {
			log.error(e1);
		}
	}
	
}
