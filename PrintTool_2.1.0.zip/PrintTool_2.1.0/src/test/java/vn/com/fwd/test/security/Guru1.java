package vn.com.fwd.test.security;

public class Guru1 extends Guru {
	public Guru1(String abc) {
		namePub = abc;
	}
}
