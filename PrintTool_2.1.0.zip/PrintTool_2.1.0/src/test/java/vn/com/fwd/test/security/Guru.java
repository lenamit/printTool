package vn.com.fwd.test.security;

public class Guru {
	private String name;
	public String namePub;
	
	static public void main(String[] args){
		int k = 10;
		final int i;
		i = 10;
		final int m = 10;
		switch (k) {
			default : System.out.println(k);
			case 1: System.out.println(i);
			case 10*2-20 : System.out.println("case 2");
			break;
		}
	}
}
