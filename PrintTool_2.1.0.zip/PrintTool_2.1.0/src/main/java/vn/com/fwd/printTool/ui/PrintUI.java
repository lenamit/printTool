package vn.com.fwd.printTool.ui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.jdesktop.swingx.JXDatePicker;

import lombok.extern.log4j.Log4j;
import vn.com.fwd.printTool.dto.ReportDTO;
import vn.com.fwdprintTool.services.PrintToolServices;

@Log4j
public class PrintUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private PrintToolServices printToolServices;
	
	// jcombobox policy type
	// table policy type
	
	public PrintUI() {
		try {
			if (printToolServices == null) {
				printToolServices = PrintToolServices.getInstant();
			}
			initComponents();
		} catch (Exception e){
			JOptionPane.showMessageDialog(null, "user name, password is incorrect !");
			System.out.println(e.getMessage());
		}
	}
	
	private void initComponents() {
		try {
			setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			JTabbedPane tabbedPane = new JTabbedPane();
			tabbedPane.addTab("Print Auto", makePanelPrintByService());
			tabbedPane.addTab("Print By Excel", makePanelPrintByExcel());
			getContentPane().add(tabbedPane);
			
			pack();
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	private JComponent makePanelPrintByService() {
		try {
			JPanel panel = new JPanel(false);
	        panel.setLayout(null);
	        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
			
			final DateFormat df = new SimpleDateFormat("ddMMyyyy");
	        // policy type
	        JLabel lTypePolicy = new JLabel("Type Policy:");
	        lTypePolicy.setBounds(35, 23, 80, 14);
	        panel.add(lTypePolicy);
	        final JComboBox<String> comTypePolicys = new JComboBox<String>();
	        comTypePolicys.setBounds(125, 20, 200, 20);
	        // get from config
	        List<String> lstPolicyType = printToolServices.getAllpolicyType();
	        if (lstPolicyType != null) {
	        	for (String policyType : lstPolicyType) {
	        		comTypePolicys.addItem(policyType);
	        	}
	        }
	        panel.add(comTypePolicys);
	        
	        // report date
	        JLabel lDate = new JLabel("Report Date:");
	        lDate.setBounds(35, 48, 80, 14);
	        panel.add(lDate);
	        final JXDatePicker jDateReport = new JXDatePicker();
	        jDateReport.setBounds(125, 45, 200, 20);
	        Date tmpDateRepot = getDate(-1);
	        jDateReport.setDate(tmpDateRepot);
	        jDateReport.setFormats(new SimpleDateFormat("dd-MM-yyyy"));
	        panel.add(jDateReport);
	        
	        // path save Excel file
	        JLabel lFileExcel = new JLabel("Excel Report:");
	        lFileExcel.setBounds(35, 73, 80, 14);
	        panel.add(lFileExcel);
	        final JTextField fFolderExcel = new JTextField();
	        fFolderExcel.setBounds(125, 70, 200, 20);
	        panel.add(fFolderExcel);
	        JButton bBrower = new JButton("Brower");
	        bBrower.setBounds(330, 70, 80, 20);
	        panel.add(bBrower);
	        
	        final JFileChooser fileExcel = new JFileChooser();
	        //set a default filename (this is where you default extension first comes in)
	        String fileName = "DS HD PHAT HANH " + df.format(jDateReport.getDate() == null ? tmpDateRepot : jDateReport.getDate()) + ".xlsx";
	        fileExcel.setSelectedFile(new File(fileName));
	        //Set an extension filter, so the user sees other XML files
	        fileExcel.setFileFilter(new FileNameExtensionFilter("*.xlsx","xlsx"));
	        
	        bBrower.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// set name 
					String fileNameNew = "DS HD PHAT HANH " + (String)comTypePolicys.getSelectedItem() + " " + df.format(jDateReport.getDate() == null ? new Date() : jDateReport.getDate()) + ".xlsx";
					fileExcel.setSelectedFile(new File(fileNameNew));
					int returnVal = fileExcel.showSaveDialog(PrintUI.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File file = fileExcel.getSelectedFile();
						String filePath = file.getPath();
						if (!filePath.endsWith(".xlsx")) {
							filePath += ".xlsx";
						}
						fFolderExcel.setText(filePath);
					}
				}
			});
	        
	        // chooser printer Policy
	        JLabel lPrinter = new JLabel("Printer Policy:");
	        lPrinter.setBounds(35, 98, 80, 14);
	        panel.add(lPrinter);
	        final JComboBox<String> comPrinter = new JComboBox<String>();
	        comPrinter.setBounds(125, 95, 200, 20);
	        List<String> lstPrinter = printToolServices.getAllPrinter();
	        if (lstPrinter != null && lstPrinter.size() > 0) {
	        	for (String priterName : lstPrinter) {
	        		comPrinter.addItem(priterName);
	        	}
	        }
	        PrintService defaultService = PrintServiceLookup.lookupDefaultPrintService();
	        String defaultPrinter = defaultService.getName();
	        comPrinter.setSelectedItem(defaultPrinter);
	        panel.add(comPrinter);
	        
	        // chooser printer medical card
	        JLabel lPrinterMedical = new JLabel("Printer Card:");
	        lPrinterMedical.setBounds(35, 123, 80, 14);
	        panel.add(lPrinterMedical);
	        final JComboBox<String> comPrinterCard = new JComboBox<String>();
	        comPrinterCard.setBounds(125, 120, 200, 20);
	        if (lstPrinter != null && lstPrinter.size() > 0) {
	        	for (String priterName : lstPrinter) {
	        		comPrinterCard.addItem(priterName);
	        	}
	        }
	        panel.add(comPrinterCard);
	        
	        // button report
	        JButton bReport = new JButton("Report");
	        bReport.setBounds(95, 150, 100, 30);
	        panel.add(bReport);
	        bReport.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// check empty value
					final String policyTypeNameTmp = (String) comTypePolicys.getSelectedItem();
					Date reportDateTmp = jDateReport.getDate();
					final String filePathExcelTmp = fFolderExcel.getText();
					if (!policyTypeNameTmp.isEmpty() && reportDateTmp != null && !filePathExcelTmp.isEmpty()) {
						// export excel
						printToolServices.clickBtReport(policyTypeNameTmp, reportDateTmp, filePathExcelTmp);;
					} else {
						JOptionPane.showMessageDialog(null, "please, choose Policy Type, Report Date, and Excel Report !");
					}
				}
			});
	        
	        // button Report and print
	        JButton bReportPrint = new JButton("Print and Report");
	        bReportPrint.setBounds(205, 150, 150, 30);
	        panel.add(bReportPrint);
	        bReportPrint.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// check empty value
					String policyTypeNameTmp = (String) comTypePolicys.getSelectedItem();
					Date reportDateTmp = jDateReport.getDate();
					String filePathExcelTmp = fFolderExcel.getText();
					String printerNameTmp = (String) comPrinter.getSelectedItem();
					String printerCard = (String) comPrinterCard.getSelectedItem();
					if (!policyTypeNameTmp.isEmpty() && reportDateTmp != null 
							&& !filePathExcelTmp.isEmpty() && !printerNameTmp.isEmpty() && !printerCard.isEmpty()) {
						// get data
						printToolServices.clickBtPrint(policyTypeNameTmp, reportDateTmp, filePathExcelTmp, printerNameTmp, printerCard);;
					} else {
						JOptionPane.showMessageDialog(null, "please, choose Policy Type, Report Date, Excel Report, printer policy and printer card !");
					}
				}
			});
	        
	        return panel;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
    }
	
	private JComponent makePanelPrintByExcel() {
		try {
			JPanel panel = new JPanel(false);
	        panel.setLayout(null);
			 // file excel
	        JLabel lTypePolicy = new JLabel("File Excel:");
	        lTypePolicy.setBounds(35, 13, 80, 14);
	        panel.add(lTypePolicy);
	        final JTextField jFileExcelPath = new JTextField();
	        jFileExcelPath.setBounds(125, 10, 200, 20);
	        panel.add(jFileExcelPath);
	        JButton bBrowerFileExcel = new JButton("Brower");
	        bBrowerFileExcel.setBounds(330, 10, 80, 20);
	        panel.add(bBrowerFileExcel);
	        
	        // folder pdf
	        JLabel lFolderPDF = new JLabel("Folder PDF:");
	        lFolderPDF.setBounds(35, 40, 80, 14);
	        panel.add(lFolderPDF);
	        final JTextField jFolderPDF = new JTextField();
	        jFolderPDF.setBounds(125, 37, 200, 20);
	        panel.add(jFolderPDF);
	        JButton bBrowerFolderPDF = new JButton("Brower");
	        bBrowerFolderPDF.setBounds(330, 37, 80, 20);
	        panel.add(bBrowerFolderPDF);
	        
	        // chooser printer
	        JLabel lPrinter = new JLabel("Printer PDF:");
	        lPrinter.setBounds(35, 67, 80, 14);
	        panel.add(lPrinter);
	        final JComboBox<String> comPrinter = new JComboBox<String>();
	        comPrinter.setBounds(125, 64, 200, 20);
	        List<String> lstPrinter = printToolServices.getAllPrinter();
	        if (lstPrinter != null && lstPrinter.size() > 0) {
	        	for (String priterName : lstPrinter) {
	        		comPrinter.addItem(priterName);
	        	}
	        }
	        PrintService defaultService = PrintServiceLookup.lookupDefaultPrintService();
	        String defaultPrinter = defaultService.getName();
	        comPrinter.setSelectedItem(defaultPrinter);
	        panel.add(comPrinter);
	        
	        // printer card
	        JLabel lPrinterCard = new JLabel("Printer Card:");
	        lPrinterCard.setBounds(35, 94, 80, 14);
	        panel.add(lPrinterCard);
	        final JComboBox<String> comPrinterCard = new JComboBox<String>();
	        comPrinterCard.setBounds(125, 91, 200, 20);
	        if (lstPrinter!= null && lstPrinter.size() > 0) {
	        	for (String priterName : lstPrinter) {
	        		comPrinterCard.addItem(priterName);
	        	}
	        }
	        panel.add(comPrinterCard);
	        
	        // file chooser excel
	        final JFileChooser fileExcel = new JFileChooser();
	        //Set an extension filter, so the user sees other XML files
	        fileExcel.setFileFilter(new FileNameExtensionFilter("*.xlsx","xlsx"));
	        
	        bBrowerFileExcel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int returnVal = fileExcel.showOpenDialog(PrintUI.this);
		            if (returnVal == JFileChooser.APPROVE_OPTION) {
		                File file = fileExcel.getSelectedFile();
		                jFileExcelPath.setText(file.getPath());
		            }
				}
			});
	        
	        // file chooser folder pdf
	        final JFileChooser folderPDF = new JFileChooser();
	        folderPDF.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        bBrowerFolderPDF.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int returnVal = folderPDF.showOpenDialog(PrintUI.this);
					if (returnVal == JFileChooser.APPROVE_OPTION) {
						File file = folderPDF.getSelectedFile();
						String filePath = file.getPath();
						jFolderPDF.setText(filePath);
					}
				}
			});
	        
	        // button print
	        JButton bprint = new JButton("Print");
	        bprint.setBounds(175, 121, 100, 30);
	        panel.add(bprint);
	        bprint.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					// check empty value
					final String excelPath = jFileExcelPath.getText();
					final String folderPDF = jFolderPDF.getText();
					final String printerNameTmp = (String) comPrinter.getSelectedItem();
					final String printerNameCardTmp = (String) comPrinterCard.getSelectedItem();
					if (!excelPath.isEmpty() && folderPDF != null && !printerNameTmp.isEmpty() && !printerNameCardTmp.isEmpty()) {
						// get data
						try {
							List<ReportDTO> lstPolicyTmp = null;
							try {
								lstPolicyTmp = printToolServices.readExcel(excelPath);
							} catch (Exception e2) {
								log.error(e);
								JOptionPane.showMessageDialog(null, "Format of excel input is not true !");
							}
							if (lstPolicyTmp != null) {
								final List<ReportDTO> lstPolicy = lstPolicyTmp;
								log.info("lstTmp.size(): " + lstPolicy.size());
								// export excel
								printToolServices.print(lstPolicy, folderPDF, printerNameTmp, printerNameCardTmp);
							} else {
								log.info("no data !!!!!!!!!");
							}
						} catch (Exception e1) {
							log.error(e);
						}
					} else {
						JOptionPane.showMessageDialog(null, "please, choose File Excell, Folder PDF, and Printer, and printer card !");
					}
				}
			});
	        return panel;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}
	
	private Date getDate(int numberAdd) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DAY_OF_YEAR, numberAdd);
		return cal.getTime();
	}
}
