package vn.com.fwd.printTool;

import java.awt.event.WindowAdapter;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import vn.com.fwd.printTool.ui.PrintUI;
import vn.com.fwd.printTool.util.Utils;

public class MainClass {
	private static Logger log = Logger.getLogger(MainClass.class);

	public static void main(String[] args) {
		try {
			// configuration log4j
			Properties props = Utils.getInputStreamResource("log4j.properties");
			PropertyConfigurator.configure(props);
			// load config
			Utils.loadConfiguration();
			
			PrintUI login = new PrintUI();
			login.setBounds(100, 100, 450, 260);
			login.setVisible(true);
			login.addWindowListener(new WindowAdapter() {
				@Override
				public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
		}
	}
	

}
