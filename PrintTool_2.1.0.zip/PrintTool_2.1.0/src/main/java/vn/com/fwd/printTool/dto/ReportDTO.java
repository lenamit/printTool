package vn.com.fwd.printTool.dto;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class ReportDTO {
	private int id;
	private String policyNumber;
    private String planCode;
    private String statusCode;
    private String channelCd;
    private String register;
    private Date issueDate;
    private Date afiDate;
    private String fullName;
    private String brachID;
    private String producingAgentCode;
    private String agentName;
    private String planType;
    private String fileName;
    private Date printDate;
    private boolean isMedicalRider;
    
    // print by excel
    private Date issuDate1St;
    private int numMedicalRider;
    private String lastUserAFI;
}
