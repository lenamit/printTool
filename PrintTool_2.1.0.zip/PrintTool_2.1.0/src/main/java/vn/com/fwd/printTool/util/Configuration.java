package vn.com.fwd.printTool.util;

public class Configuration {
	public static String GETALL_POLICYTYPE_URL;
	public static String GETDATA_BY_POLICYTYPE_URL;
	public static String FOLDER_PDF;
	public static String WEBSERVICE_SAVEDATA_URL;
}
