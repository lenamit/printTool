package vn.com.fwd.printTool.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import lombok.extern.log4j.Log4j;

@Log4j
public class FileUtils {
	public static List<String> getAllFile(String strFolder, String[] filterNames, String typeFile) throws Exception {
		try {
			List<String> lstResult = new ArrayList<String>();
			File folderRoot = new File(strFolder);
			if (folderRoot.exists()) {
				File[] lstFile = folderRoot.listFiles();
				if (lstFile != null) {
					for (File fileTmp : lstFile) {
						if (fileTmp.isFile()) {
							final String nameFile = fileTmp.getName();
							String nameFileUpper = nameFile.toUpperCase();
							if (!nameFileUpper.endsWith(typeFile.toUpperCase())) {
								continue;
							}
							if (filterNames != null) {
								boolean filter = true;
								for (String namePart : filterNames) {
									if (!nameFileUpper.contains(namePart.toUpperCase())) {
										filter = false;
										break;
									}
								}
								if (!filter) {
									continue;
								}
							}
							lstResult.add(fileTmp.getPath());
						} else if (fileTmp.isDirectory()) {
							lstResult.addAll(getAllFile(fileTmp.getPath(), filterNames, typeFile));
						}
					}
				}
			}
			return lstResult;
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw e;
		}
	}
}
