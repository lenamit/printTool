package vn.com.fwd.printTool.util;

import java.io.*;
import java.util.Properties;

import lombok.extern.log4j.Log4j;

@Log4j
public class Utils {
	private static Utils instant;
	
	public static Utils getInstant() {
		if (instant == null) {
			instant = new Utils();
		}
		return instant;
	}
	
    public static Properties getInputStreamResource(String fileName) {
		Utils utils = new Utils();
		ClassLoader classLoader = utils.getClass().getClassLoader();
		Properties props = new Properties();
		InputStream resourceStream = classLoader.getResourceAsStream(fileName);
	    try {
			props.load(resourceStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (resourceStream != null) {
				try {
					resourceStream.close();
					resourceStream = null;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return props;
	}
    
    public static Properties getPropertiesFromRoot(String fileName) {
		Properties props = new Properties();
		InputStream resourceStream = ClassLoader.getSystemResourceAsStream(fileName);
	    try {
			props.load(resourceStream);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (resourceStream != null) {
				try {
					resourceStream.close();
					resourceStream = null;
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return props;
	}
    
    private static Properties loadProppertiesOutside(String filePath) {
    	FileInputStream file;
    	Properties mainProperties = new Properties();
		try {
			file = new FileInputStream(filePath);
			mainProperties.load(file);
		} catch (FileNotFoundException e) {
			log.error(e);
		} catch (IOException e) {
			log.error(e);
		}
    	return mainProperties;
    }
    
    public static void loadConfiguration() {
    	Properties prop = loadProppertiesOutside("./config.properties");
    	Configuration.GETALL_POLICYTYPE_URL = prop.getProperty("GETALL_POLICYTYPE_URL");
    	log.info("GETALL_POLICYTYPE_URL : " + Configuration.GETALL_POLICYTYPE_URL);
    	Configuration.GETDATA_BY_POLICYTYPE_URL = prop.getProperty("GETDATA_BY_POLICYTYPE_URL");
    	log.info("GETDATA_BY_POLICYTYPE_URL : " + Configuration.GETDATA_BY_POLICYTYPE_URL);
    	Configuration.FOLDER_PDF = prop.getProperty("FOLDER_PDF");
    	log.info("FOLDER_PDF : " + Configuration.FOLDER_PDF);
    	Configuration.WEBSERVICE_SAVEDATA_URL = prop.getProperty("WEBSERVICE_SAVEDATA_URL");
    	log.info("WEBSERVICE_SAVEDATA_URL : " + Configuration.WEBSERVICE_SAVEDATA_URL);
    }
}