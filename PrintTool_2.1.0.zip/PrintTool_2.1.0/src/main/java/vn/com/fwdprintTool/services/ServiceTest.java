package vn.com.fwdprintTool.services;

import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.extern.log4j.Log4j;

@Log4j
public class ServiceTest {
	private List<Map> getDataByPolicyType(String policyType, Date reportDate) {
		try {
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setMessageConverters(getMessageConverters());
			String url = UriComponentsBuilder.fromHttpUrl("http://localhost:8080/print/getDataReport"/*Configuration.GETDATA_BY_POLICYTYPE_URL*/)
			.queryParam("Policy_Type", policyType).queryParam("Report_Date", df.format(reportDate))
			.toUriString();
    		List<Map> lstData = Arrays.asList(restTemplate.getForObject(url, Map[].class));
    		return lstData;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}
	
	private List<HttpMessageConverter<?>> getMessageConverters() {
	    List<HttpMessageConverter<?>> converters = 
	      new ArrayList<HttpMessageConverter<?>>();
	    converters.add(new MappingJackson2HttpMessageConverter());
	    return converters;
	}
	
	public static void main(String[] args) {
		try {
			Date reportDate = new Date(117, 7, 17);
			ServiceTest service = new ServiceTest();
			List<Map> lstData = service.getDataByPolicyType("All_VIET", reportDate);
			service.exportExcell(lstData, "C:\\Users\\vnuser10\\Documents\\RePort_TEST.xlsx", "DATA_ALL");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void exportExcell(List<Map> lstData, String filePathExcel, String sheetName) throws Exception {
		try {
			if (lstData != null && lstData.size() > 0) {
				Set<String> lstHeader = lstData.get(0).keySet();
				// excel
				XSSFWorkbook workbook = new XSSFWorkbook();
				// sheet 
		        XSSFSheet sheet = workbook.createSheet(sheetName);
		        // cell style
		        DataFormat dataformat = workbook.createDataFormat();
	            CellStyle styleDate = workbook.createCellStyle();
	            styleDate.setDataFormat(dataformat.getFormat("dd-MM-yyyy"));
				
				int rowNum = 0;
				Row rowHeader = sheet.createRow(rowNum++);
				Cell cellHeader0 = rowHeader.createCell(0);
				cellHeader0.setCellValue("STT");
				int column = 1;
				for (String header : lstHeader) {
					Cell cellHeader = rowHeader.createCell(column++);
					cellHeader.setCellValue(header);
				}

				for (Map<String, Object> report : lstData) {
		        	Row row = sheet.createRow(rowNum);
		        	Cell cellData0 = row.createCell(0);
		        	cellData0.setCellValue(rowNum);
		        	rowNum++;
		        	column = 1;
		        	for (String header : lstHeader) {
						Cell cellData = row.createCell(column++);
						cellData.setCellValue((String)report.get(header));
					}
		        }
				
				FileOutputStream outputStream = new FileOutputStream(filePathExcel);
	            workbook.write(outputStream);
	            workbook.close();
	            log.info("Done Excel");
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
 }
