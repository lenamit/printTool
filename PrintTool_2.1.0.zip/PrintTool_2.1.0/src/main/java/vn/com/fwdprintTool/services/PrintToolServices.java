package vn.com.fwdprintTool.services;

import java.awt.print.PrinterJob;
import java.io.*;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import javax.print.PrintService;
import javax.print.attribute.HashPrintRequestAttributeSet;
import javax.print.attribute.PrintRequestAttributeSet;
import javax.print.attribute.standard.OrientationRequested;
import javax.print.attribute.standard.Sides;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.printing.PDFPageable;
import org.apache.pdfbox.printing.PDFPrintable;
import org.apache.pdfbox.printing.Scaling;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import lombok.extern.log4j.Log4j;
import vn.com.fwd.printTool.dto.ReportDTO;
import vn.com.fwd.printTool.util.Configuration;
import vn.com.fwd.printTool.util.FileUtils;
import vn.com.fwd.printTool.util.Utils;

@Log4j
public class PrintToolServices extends Utils {
	private static PrintToolServices instant;
	
	public static PrintToolServices getInstant() {
		if (instant == null) {
			instant = new PrintToolServices();
		}
		return instant;
	}
	
	/**
	 * method implement click button report
	 * @param policyTypeNameTmp : policy type
	 * @param reportDateTmp : issue date
	 * @param filePathExcelTmp : path of file excel
	 */
	public void clickBtReport(String policyTypeNameTmp, Date reportDateTmp, String filePathExcelTmp) {
		try {
			final List<ReportDTO> lstTmp = getDataByPolicyType(policyTypeNameTmp, reportDateTmp);
			if (lstTmp != null) {
				log.info("lstTmp.size(): " + lstTmp.size());
				// export excel
				toExcel(lstTmp, filePathExcelTmp, policyTypeNameTmp);
			} else {
				log.info("no data !!!!!!!!!");
			}
		} catch (Exception e1) {
			log.error(e1);
		}
	}
	
	/**
	 * method implement click button print and report
	 * @param policyTypeNameTmp : policy type
	 * @param reportDateTmp : issue date
	 * @param filePathExcelTmp : path of file excel
	 */
	public void clickBtPrint(final String policyTypeNameTmp, Date reportDateTmp, final String filePathExcelTmp, final String printerPolicy, final String printerMedicalCard) {
		try {
			final List<ReportDTO> lstTmp = getDataByPolicyType(policyTypeNameTmp, reportDateTmp);
			if (lstTmp != null) {
				log.info("lstTmp.size(): " + lstTmp.size());
				// export excel
				Thread tExportExcel = new Thread() {
					public void run() {
						// export excel
						try {
							toExcel(lstTmp, filePathExcelTmp, policyTypeNameTmp);
						} catch (SQLException e) {
							log.error(e);
						}
					};
				};
				tExportExcel.start();
				// print document
				Thread tPrint = new Thread() {
					public void run() {
						try {
							printPDF(lstTmp, printerPolicy, printerMedicalCard);
						} catch (Exception e) {
							log.error(e);
						}
					};
				};
				tPrint.start();
				// wait thread end
				tExportExcel.join();
				tPrint.join();
			} else {
				System.out.println("no data !!!!!!!!!");
			}
		} catch (Exception e1) {
			log.error(e1);
		}
	}
	
	/**
	 * Method print pdf by lst policy
	 * @param lstReport
	 * @param printerName
	 * @throws Exception
	 */
	private void printPDF(List<ReportDTO> lstReport, final String printerPolicy, final String printerMedicalCard) throws Exception {
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		try {
			log.info(df.format(new Date()) + " : Begin Print !");
			File pdffolder = new File(Configuration.FOLDER_PDF);
			if (pdffolder.exists()) {
				List<ReportDTO> lstPrintLog = new ArrayList<ReportDTO>();
				for (ReportDTO report : lstReport) {
					final String policyNumber = report.getPolicyNumber();
					// find file Name by policy number
					// find file Name by policy number
					String[] filterFiles = {"_" + policyNumber + "_", "_ZLPOL"};
					List<String> lstofpdf = FileUtils.getAllFile(Configuration.FOLDER_PDF, filterFiles, ".PDF");
					if (lstofpdf != null && lstofpdf.size() > 0) {
						// get only file correct
						String filePath = lstofpdf.get(0);
						
						// print policy
						final String filePathTmp = filePath;
						Thread threadPrintPolicy = new Thread(new Runnable() {
							public void run() {
								try {
									printPolicy(printerPolicy, filePathTmp);
								} catch (Exception e) {
									e.printStackTrace();
								}
								
							}
						});
						threadPrintPolicy.start();
						if (report.isMedicalRider()) {
							// get file path card
							String[] filterFilesCard = {"_" + policyNumber + "_", "_ZMEDCARD"};
							List<String> lstCardPath = FileUtils.getAllFile(Configuration.FOLDER_PDF, filterFilesCard, ".PDF");
							// print card
							if (lstCardPath != null && lstCardPath.size() > 0) {
								for (String cardPath : lstCardPath) {
									printCard(printerMedicalCard, cardPath, report.getNumMedicalRider());
								}
							}
						}
						
						// save to database
						report.setFileName(filePath);
						report.setPrintDate(new Date());
						lstPrintLog.add(report);
						
						threadPrintPolicy.join();
					} else {
						log.warn("File of policy number " + policyNumber + " is not exist in " + Configuration.FOLDER_PDF);
					}
				}
				saveInforPolicy(lstPrintLog);
			} else {
				log.warn("Foldef" + Configuration.FOLDER_PDF + " is not exist !");
			}
			log.info(df.format(new Date()) + " : Print Done !");
		} catch (Exception e) {
			log.error(e);
			throw e;
		}
	}
	
	/**
	 * find printer
	 * @param printerName
	 * @return
	 * @throws Exception
	 */
	private PrintService findPrintService(String printerName) throws Exception {
		try {
	        printerName = printerName.toLowerCase();
	        PrintService service = null;
	        // Get array of all print services
	        PrintService[] services = PrinterJob.lookupPrintServices();
	        // Retrieve a print service from the array
	        for (int index = 0; service == null && index < services.length; index++) {
	            if (services[index].getName().toLowerCase().indexOf(printerName) >= 0) {
	                service = services[index];
	            }
	        }
	        // Return the print service
	        return service;
		} catch (Exception e) {
			log.error(e);
			
			throw e;
		}
    }
	
	/**
	 * find all printer
	 * @return
	 * @throws Exception
	 */
	public List<String> getAllPrinter() throws Exception{
		try {
			List<String> lstResult = new ArrayList<String>();
			PrintService[] services = PrinterJob.lookupPrintServices();
			for (PrintService printer : services) {
				lstResult.add(printer.getName());
			}
			return lstResult;
		} catch (Exception e) {
			log.error(e);
			
			throw e;
		}
	}
	
	/**
	 * method print policy
	 * @param printerName : printer name
	 * @param filePath : file path
	 * @throws Exception
	 */
	private void printPolicy(String printerName, String filePath) throws Exception {
		try {
			File filePDF = new File(filePath);
			PDDocument document = PDDocument.load(filePDF);
			PrintService service = findPrintService(printerName);
			PrinterJob job = PrinterJob.getPrinterJob();
			job.setPageable(new PDFPageable(document));
			job.setPrintService(service);
			job.setJobName(filePDF.getName());
			PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
			pras.add(Sides.DUPLEX);
		    job.print(pras);
		    document.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * method : print card medical
	 * @param printerName : printer name
	 * @param filePath : file path
	 * @throws Exception
	 */
	private void printCard(String printerName, String filePath, int numberOfCard) throws Exception {
		try {
			File filePDF = new File(filePath);
			PDDocument document = PDDocument.load(filePDF);
			int numberPages = document.getNumberOfPages();
			if (numberPages != numberOfCard) {
				log.warn("Number of pages (" + numberPages + ") file " + filePath + " is not match with number of card (" + numberOfCard + ") in Excel");
			}
			PrintService service = findPrintService(printerName);
			PrinterJob job = PrinterJob.getPrinterJob();
			PDFPrintable printable = new PDFPrintable(document, Scaling.SHRINK_TO_FIT);
			job.setPrintable(printable);
			job.setPrintService(service);
			job.setJobName(filePDF.getName());
			PrintRequestAttributeSet pras = new HashPrintRequestAttributeSet();
			pras.add(OrientationRequested.PORTRAIT);
		    job.print(pras);
		    document.close();
			// save to database
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	private void saveInforPolicy(List<ReportDTO> lstPrint) {
		try {
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setMessageConverters(getMessageConverters());
			HttpHeaders headers = new HttpHeaders();
			HttpEntity<List<ReportDTO>> request = new HttpEntity<List<ReportDTO>>(lstPrint, headers);
    		restTemplate.postForObject(Configuration.WEBSERVICE_SAVEDATA_URL, request, ReportDTO.class);
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	private List<HttpMessageConverter<?>> getMessageConverters() {
	    List<HttpMessageConverter<?>> converters = 
	      new ArrayList<HttpMessageConverter<?>>();
	    converters.add(new MappingJackson2HttpMessageConverter());
	    return converters;
	}
	
	/**
	 * method save all data to excel
	 * @param lstReport
	 * @param filePathExcel
	 * @param sheetName
	 * @throws SQLException
	 */
	private void toExcel(List<ReportDTO> lstReport, String filePathExcel, String sheetName) throws SQLException {
		try {
			// excel
			XSSFWorkbook workbook = new XSSFWorkbook();
			// sheet 
	        XSSFSheet sheet = workbook.createSheet(sheetName);
	        // cell style
	        DataFormat dataformat = workbook.createDataFormat();
            CellStyle styleDate = workbook.createCellStyle();
            styleDate.setDataFormat(dataformat.getFormat("dd-MM-yyyy"));
			
			int rowNum = 0;
			// header
			String[] headers = {"STT", "C_policynumber", "C_PLANCODE", "C_STATUSCODE", "C_CHANNELCD", "C_Register", "C_IssueDate", "C_AFIDate", 
					"C_FULLNAME", "C_BRANCHID", "C_PRODUCINGAGENTCODE", "C_AGENTNAME", "C_PLANTYPE", "C_HasMedicalCard", "C_TotalsMedicalCard"};
			Row rowHeader = sheet.createRow(rowNum++);
			for (int i = 0; i < headers.length; i++) {
				Cell cellHeader = rowHeader.createCell(i);
				cellHeader.setCellValue(headers[i]);
			}

			for (ReportDTO report : lstReport) {
	        	Row row = sheet.createRow(rowNum);
	        	Cell cellStt = row.createCell(0);
	        	cellStt.setCellValue(rowNum);
	        	rowNum++;
	        	
            	Cell cellpolicynumber = row.createCell(1);
            	cellpolicynumber.setCellValue(report.getPolicyNumber());
            	
            	Cell cellPLANCODE = row.createCell(2);
            	cellPLANCODE.setCellValue(report.getPlanCode());
            	
            	Cell cellSTATUSCODE = row.createCell(3);
            	cellSTATUSCODE.setCellValue(report.getStatusCode());
            	
            	Cell cellCHANNELCD = row.createCell(4);
            	cellCHANNELCD.setCellValue(report.getChannelCd());
            	
            	Cell cellRegister = row.createCell(5);
            	cellRegister.setCellValue(report.getRegister());
            	
            	Cell cellIssueDate = row.createCell(6);
            	cellIssueDate.setCellValue(report.getIssueDate());
            	cellIssueDate.setCellStyle(styleDate);
            	
            	Cell cellAFIDate = row.createCell(7);
            	cellAFIDate.setCellValue(report.getAfiDate());
            	cellAFIDate.setCellStyle(styleDate);
            	
            	Cell cellFULLNAME = row.createCell(8);
            	cellFULLNAME.setCellValue(report.getFullName());
            	
            	Cell cellBRANCHID = row.createCell(9);
            	cellBRANCHID.setCellValue(report.getBrachID());
            	
            	Cell cellPRODUCINGAGENTCODE = row.createCell(10);
            	cellPRODUCINGAGENTCODE.setCellValue(report.getProducingAgentCode());
            	
            	Cell cellAGENTNAME = row.createCell(11);
            	cellAGENTNAME.setCellValue(report.getAgentName());
            	
            	Cell cellPLANTYPE = row.createCell(12);
            	cellPLANTYPE.setCellValue(report.getPlanType());
            	
            	Cell cellHasMedicalCard = row.createCell(13);
            	cellHasMedicalCard.setCellValue(report.isMedicalRider());
            	
            	Cell cellTotalsCard = row.createCell(14);
            	cellTotalsCard.setCellValue(report.getNumMedicalRider());
	        }
			
			FileOutputStream outputStream = new FileOutputStream(filePathExcel);
            workbook.write(outputStream);
            workbook.close();
            log.info("Done Excel");
		} catch (Exception e) {
			log.error(e);
		}
	}
	
	/**
	 * call service get all policy
	 * @return
	 */
	public List<String> getAllpolicyType() {
		try {
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setMessageConverters(getMessageConverters());
    		List<String> lstPolicy = Arrays.asList(restTemplate.getForObject(Configuration.GETALL_POLICYTYPE_URL, String[].class));
    		return lstPolicy;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	private List<ReportDTO> getDataByPolicyType(String policyType, Date reportDate) {
		try {
			DateFormat df = new SimpleDateFormat("yyyyMMdd");
			RestTemplate restTemplate = new RestTemplate();
			restTemplate.setMessageConverters(getMessageConverters());
			String url = UriComponentsBuilder.fromHttpUrl(Configuration.GETDATA_BY_POLICYTYPE_URL)
			.queryParam("Policy_Type", policyType).queryParam("Report_Date", df.format(reportDate))
			.toUriString();
    		List<ReportDTO> lstData = Arrays.asList(restTemplate.getForObject(url, ReportDTO[].class));
    		return lstData;
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}
	
	/**
	 * method print policy by excel
	 * @param lstReport : list policy
	 * @param folderPath : folder parent pdf file
	 * @param printerPolicy : name printer policy
	 * @param printerCard : name of printer card
	 * @throws Exception
	 */
	public void print(List<ReportDTO> lstReport, String folderPath, final String printerPolicy, final String printerCard) throws Exception {
		DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
		try {
			log.info(df.format(new Date()) + " : Begin Print !");
			System.out.println(df.format(new Date()) + " : Begin Print !");
			List<ReportDTO> lstPrintLog = new ArrayList<ReportDTO>();
			for (ReportDTO report : lstReport) {
				final String policyNumber = report.getPolicyNumber();
				File pdffolder = new File(folderPath);
				if (pdffolder.exists()) {
					// find file Name by policy number
					String[] filterFiles = {"_" + policyNumber + "_", "_ZLPOL"};
					List<String> lstofpdf = FileUtils.getAllFile(folderPath, filterFiles, ".PDF");
					if (lstofpdf != null && lstofpdf.size() > 0) {
						// get only file correct
						String filePath = lstofpdf.get(0);
						if (!filePath.isEmpty()) {
							// print policy
							final String filePathTmp = filePath;
							Thread threadPrintPolicy = new Thread(new Runnable() {
								public void run() {
									try {
										printPolicy(printerPolicy, filePathTmp);
									} catch (Exception e) {
										e.printStackTrace();
									}
									
								}
							});
							threadPrintPolicy.start();
							if (report.isMedicalRider()) {
								// get file path card
								String[] filterFilesCard = {"_" + policyNumber + "_", "_ZMEDCARD"};
								List<String> lstCardPath = FileUtils.getAllFile(folderPath, filterFilesCard, ".PDF");
								// print card
								if (lstCardPath != null && lstCardPath.size() > 0) {
									for (String cardPath : lstCardPath) {
										printCard(printerCard, cardPath, report.getNumMedicalRider());
									}
								}
							}
							
							// save to database
							report.setFileName(filePath);
							report.setPrintDate(new Date());
							lstPrintLog.add(report);
							
							threadPrintPolicy.join();
						} else {
							log.warn("File of policy number " + policyNumber + " is not exist in " + folderPath);
						}
					} else {
						log.warn("File of policy number " + policyNumber + " is not exist in " + folderPath);
					}
				}
			}
			saveInforPolicy(lstPrintLog);
			
			log.info(df.format(new Date()) + " : Print Done !");
		} catch (Exception e) {
			log.error(e);
			throw e;
		}
	}
	
	/**
	 * 
	 * @param filePathExcel
	 * @return
	 * @throws Exception
	 */
	public List<ReportDTO> readExcel(String filePathExcel) throws Exception {
		List<ReportDTO> lstResut = new ArrayList<ReportDTO>();
		Workbook workbook = null;
		try {
			FileInputStream excelFile = new FileInputStream(new File(filePathExcel));
            workbook = new XSSFWorkbook(excelFile);
            Sheet datatypeSheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = datatypeSheet.iterator();
            while (iterator.hasNext()) {
            	ReportDTO report = new ReportDTO();
                Row currentRow = iterator.next();
                if (currentRow.getRowNum() == 0) {
                	continue;
                }
                DataFormatter formatter = new DataFormatter();
                Cell cellPolicy = currentRow.getCell(1);
                if (cellPolicy != null) {
	                report.setPolicyNumber(formatter.formatCellValue(cellPolicy));
	//                report.setPlanCode(formatter.formatCellValue(currentRow.getCell(2)));
	            	report.setStatusCode(formatter.formatCellValue(currentRow.getCell(2)));
	            	report.setChannelCd(formatter.formatCellValue(currentRow.getCell(3)));
	            	report.setRegister(formatter.formatCellValue(currentRow.getCell(4)));
	            	report.setIssuDate1St(currentRow.getCell(5).getDateCellValue());
	            	report.setIssueDate(currentRow.getCell(6).getDateCellValue());
	            	report.setAfiDate(currentRow.getCell(7).getDateCellValue());
	            	//
	            	report.setLastUserAFI(formatter.formatCellValue(currentRow.getCell(8)));
	            	//
	            	report.setFullName(formatter.formatCellValue(currentRow.getCell(9)));
	            	report.setBrachID(formatter.formatCellValue(currentRow.getCell(10)));
	            	report.setProducingAgentCode(formatter.formatCellValue(currentRow.getCell(11)));
	            	report.setAgentName(formatter.formatCellValue(currentRow.getCell(12)));
	            	String medical = formatter.formatCellValue(currentRow.getCell(13));
	            	if ("Y".equalsIgnoreCase(medical)) {
	            		report.setMedicalRider(true);
	            	} else {
	            		report.setMedicalRider(false);
	            	}
	            	report.setNumMedicalRider(!"".equals(formatter.formatCellValue(currentRow.getCell(14))) ? Integer.parseInt(formatter.formatCellValue(currentRow.getCell(14))) : 0);
	            	
	                lstResut.add(report);
                }
            }
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw e;
		} finally {
			if (workbook != null) {workbook.close(); workbook = null;}
		}
		return lstResut;
	}
}
